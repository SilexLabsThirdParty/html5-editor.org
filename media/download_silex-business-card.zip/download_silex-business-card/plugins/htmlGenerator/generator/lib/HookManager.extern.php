<?php

{
	require_once("cgi/includes/HookManager.php");
}