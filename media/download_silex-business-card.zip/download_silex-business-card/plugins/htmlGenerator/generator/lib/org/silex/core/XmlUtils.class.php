<?php

class org_silex_core_XmlUtils {
	public function __construct(){}
	static $INDENT_STRING = "\x09";
	static function xml2StringIndent($xml) {
		$firstElement = $xml->firstElement();
		return org_silex_core_XmlUtils::xml2StringIndentRecursive($firstElement, "");
	}
	static function xml2StringIndentRecursive($xml, $indentationLevel) {
		$toReturn = "";
		$toReturn .= $indentationLevel . "<" . $xml->getNodeName();
		if(null == $xml) throw new HException('null iterable');
		$�it = $xml->attributes();
		while($�it->hasNext()) {
			$attrib = $�it->next();
			$toReturn .= " " . $attrib . "=\"" . $xml->get($attrib) . "\"";
		}
		$toReturn .= ">";
		$firstChild = $xml->firstChild();
		if($firstChild !== null) {
			switch($firstChild->nodeType) {
			case Xml::$CData:{
				$toReturn .= "<![CDATA[" . $firstChild->getNodeValue() . "]]>";
			}break;
			case Xml::$PCData:{
				$toReturn .= $firstChild;
			}break;
			case Xml::$Element:{
				$toReturn .= "\x0A";
				$element = null;
				if(null == $xml) throw new HException('null iterable');
				$�it = $xml->iterator();
				while($�it->hasNext()) {
					$element1 = $�it->next();
					$toReturn .= org_silex_core_XmlUtils::xml2StringIndentRecursive($element1, $indentationLevel . "\x09");
				}
				$toReturn .= $indentationLevel;
			}break;
			default:{
			}break;
			}
		}
		$toReturn .= "</" . $xml->getNodeName() . ">\x0A";
		return $toReturn;
	}
	function __toString() { return 'org.silex.core.XmlUtils'; }
}
