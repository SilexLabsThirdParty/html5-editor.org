<?php

{
	require_once("cgi/includes/config_editor.php");
}