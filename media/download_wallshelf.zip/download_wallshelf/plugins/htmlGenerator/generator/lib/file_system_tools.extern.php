<?php

{
	require_once("cgi/includes/file_system_tools.php");
}