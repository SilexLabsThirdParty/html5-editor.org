<?php

{
	require_once("cgi/includes/server_config.php");
}